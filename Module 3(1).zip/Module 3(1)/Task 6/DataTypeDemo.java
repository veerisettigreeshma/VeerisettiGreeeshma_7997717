public class DataTypeDemo {
    public static void main(String[] args) {

        int a = 100;
        float b = 12.5f;
        double c = 45.678;
        char d = 'G';
        boolean e = true;

        System.out.println("Int = " + a);
        System.out.println("Float = " + b);
        System.out.println("Double = " + c);
        System.out.println("Char = " + d);
        System.out.println("Boolean = " + e);
    }
}