USE event_portal;
SELECT event_id, AVG(rating) AS avg_rating, COUNT(feedback_id) AS total_feedback
FROM Feedback
GROUP BY event_id
HAVING COUNT(feedback_id) >= 10
ORDER BY avg_rating DESC;