import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class VirtualThreadDemo {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== VIRTUAL THREADS DEMO ===");
        
        // We will attempt to run 100,000 tasks concurrently!
        int numberOfTasks = 100_000;
        List<Thread> threads = new ArrayList<>();

        System.out.println("Spinning up " + numberOfTasks + " virtual threads...");
        Instant start = Instant.now();

        for (int i = 0; i < numberOfTasks; i++) {
            final int taskId = i;
            
            // Create a virtual thread using the modern Builder API
            Thread vThread = Thread.ofVirtual().unstarted(() -> {
                try {
                    // Simulate a lightweight blocking network or DB delay (1 second)
                    Thread.sleep(Duration.ofSeconds(1));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                
                // Print a quick message from just a few threads so we don't spam the console
                if (taskId % 25000 == 0) {
                    System.out.println("Task " + taskId + " executed by: " + Thread.currentThread());
                }
            });

            threads.add(vThread);
        }

        // Start all 100,000 virtual threads running concurrently
        for (Thread t : threads) {
            t.start();
        }

        // Wait for all 100,000 threads to finish working
        for (Thread t : threads) {
            t.join();
        }

        Instant end = Instant.now();
        long timeElapsed = Duration.between(start, end).toMillis();
        
        System.out.println("------------------------------------");
        System.out.println("All " + numberOfTasks + " tasks completed successfully!");
        System.out.println("Total Execution Time: " + timeElapsed + " ms (" + (timeElapsed / 1000.0) + " seconds)");
    }
}