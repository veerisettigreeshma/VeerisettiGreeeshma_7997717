import java.util.HashMap;

public class HashMapDemo {

    public static void main(String[] args) {

        HashMap<Integer,String> map =
                new HashMap<>();

        map.put(101,"Greeshma");
        map.put(102,"Anu");
        map.put(103,"Priya");

        System.out.println(
                map.get(102));
    }
}