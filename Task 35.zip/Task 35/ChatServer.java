import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ChatServer {
    public static void main(String[] args) {
        System.out.println("=== SERVER STARTED ===");
        System.out.println("Waiting for a client to connect...");
        
        // Open port 5000 to listen for incoming connections
        try (ServerSocket serverSocket = new ServerSocket(5000);
             Socket clientSocket = serverSocket.accept(); // Pauses here until a client connects
             PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
             BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in))) {
            
            System.out.println("Client connected! You can start chatting now.");
            System.out.println("----------------------------------------");
            
            String clientMessage, serverMessage;
            
            // Keep reading messages from the client
            while ((clientMessage = in.readLine()) != null) {
                System.out.println("Client says: " + clientMessage);
                
                // If the client types 'bye', end the chat session
                if ("bye".equalsIgnoreCase(clientMessage)) {
                    System.out.println("Client closed the connection.");
                    break;
                }
                
                // Prompt the server user to type a reply
                System.out.print("Your Reply (Server): ");
                serverMessage = stdIn.readLine();
                out.println(serverMessage);
            }
        } catch (Exception e) {
            System.err.println("Server exception: " + e.getMessage());
        }
    }
}