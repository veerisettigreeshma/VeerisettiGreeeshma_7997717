USE event_portal;
SELECT event_id, title 
FROM Events
WHERE event_id IN (SELECT event_id FROM Registrations)
  AND event_id NOT IN (SELECT event_id FROM Feedback);