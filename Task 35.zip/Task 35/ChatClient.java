import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ChatClient {
    public static void main(String[] args) {
        System.out.println("=== CLIENT STARTED ===");
        System.out.println("Attempting to connect to the server at localhost:5000...");
        
        // Connect to the server running on 'localhost' at port 5000
        try (Socket socket = new Socket("localhost", 5000);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in))) {
            
            System.out.println("Successfully connected to the Server! Start typing below.");
            System.out.println("Type 'bye' to exit the chat.");
            System.out.println("----------------------------------------");
            
            String userInput, serverResponse;
            
            while (true) {
                // Prompt the client user to type a message
                System.out.print("Your Message (Client): ");
                userInput = stdIn.readLine();
                
                // Send the message to the server
                out.println(userInput);
                
                if ("bye".equalsIgnoreCase(userInput)) {
                    System.out.println("Closing connection...");
                    break;
                }
                
                // Wait for the server to reply and print it
                serverResponse = in.readLine();
                System.out.println("Server says: " + serverResponse);
            }
        } catch (Exception e) {
            System.err.println("Client exception: " + e.getMessage());
        }
    }
}