
sealed interface PaymentMethod permits CreditCard, PayPal {
    void processPayment(double amount);
}

final class CreditCard implements PaymentMethod {
    @Override
    public void processPayment(double amount) {
        System.out.println("Processing Credit Card payment of $" + amount);
    }
}

non-sealed class PayPal implements PaymentMethod {
    @Override
    public void processPayment(double amount) {
        System.out.println("Processing PayPal payment of $" + amount);
    }
}

public class SealedClassesDemo {
    public static void main(String[] args) {
        System.out.println("=== SEALED CLASSES DEMO ===");
        System.out.println("------------------------------------");

        PaymentMethod card = new CreditCard();
        PaymentMethod cryptoWallet = new PayPal();

        card.processPayment(150.50);
        cryptoWallet.processPayment(89.99);

        checkPaymentType(card);
        checkPaymentType(cryptoWallet);
    }

    public static void checkPaymentType(PaymentMethod pm) {
        switch (pm) {
            case CreditCard cc -> System.out.println("Verified: Secure card transaction.");
            case PayPal pp -> System.out.println("Verified: Digital wallet transaction.");
        }
    }
}
