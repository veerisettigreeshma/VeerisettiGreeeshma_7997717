record Person(String name, int age) {}

public class RecordDemo {

    public static void main(String[] args) {

        Person p1 =
                new Person("Greeshma",20);

        Person p2 =
                new Person("Anu",17);

        System.out.println(p1);
        System.out.println(p2);
    }
}
