# Event Portal Database Project

## Author
Veerisetti Greeshma

## Project Description
This project contains SQL scripts for the Event Portal Database. The database is designed to manage event-related information such as events, participants, registrations, and other related data.

## Database Configuration

Connection Name : MySQL80

Server          : 127.0.0.1

Port            : 3306

Username        : root

Password        : root@123

Database        : event_portal

## Software Requirements

- MySQL Server 8.0 or above
- MySQL Workbench

## Steps to Run the Project

1. Start MySQL Server.
2. Open MySQL Workbench.
3. Connect using the following details:

   Connection Name : MySQL80

   Server          : 127.0.0.1

   Port            : 3306

   Username        : root

   Password        : root@123

4. Open the SQL script file.
5. Select the database:

   ```sql
   USE event_portal;
   ```

6. Execute the SQL statements using the Execute (⚡) button.
7. Verify the output in the Result Grid.

## Database Name

```sql
event_portal
```

## Features

- Database Creation
- Table Creation
- Data Insertion
- Data Retrieval
- Data Filtering
- Data Updating
- Data Deletion
- SQL Query Execution

## Files Included

- Task1.sql
- Task2.sql
- Task3.sql
- ...
- Task25.sql

## Notes

- Ensure MySQL Server is running before executing the scripts.
- Execute the scripts in the order specified if dependencies exist.
- Verify that the `event_portal` database is available before running queries.

## Output

The SQL scripts can be executed successfully through MySQL Workbench using the above connection details and database configuration.