USE event_portal;
SELECT user_id, full_name, registration_date
FROM Users
WHERE registration_date >= CURDATE() - INTERVAL 30 DAY
  AND user_id NOT IN (SELECT user_id FROM Registrations);