import java.util.ArrayList;

public class ArrayListDemo {

    public static void main(String[] args) {

        ArrayList<String> students =
                new ArrayList<>();

        students.add("Greeshma");
        students.add("Anu");
        students.add("Priya");

        for(String name : students) {
            System.out.println(name);
        }
    }
}
