import java.util.spi.ToolProvider;

public class RunJavap {
    public static void main(String[] args) {
        // Find the built-in javap tool inside the running JDK
        ToolProvider javap = ToolProvider.findFirst("javap")
            .orElseThrow(() -> new RuntimeException("javap tool not found!"));
        
        System.out.println("=== DISASSEMBLING BYTECODE ===");
        // Run it directly against your BytecodeDemo class file
        javap.run(System.out, System.err, "-c", "BytecodeDemo");
    }
}