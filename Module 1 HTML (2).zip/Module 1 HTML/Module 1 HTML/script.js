/* Phone Validation */

function validatePhone(){

    let phone =
    document.getElementById("phone").value;

    if(phone.length != 10){

        alert(
        "Phone number must contain exactly 10 digits"
        );

    }else{

        alert("Valid Phone Number");
    }
}

/* Event Fee Display */

function showFee(){

    let fee =
    document.getElementById("eventType").value;

    document.getElementById("feeBox")
    .innerHTML =

    "Event Fee: ₹" + fee;
}

/* Submit Confirmation */

function showConfirmation(){

    let name =
    document.getElementById("name").value;

    document.getElementById("outputMessage")
    .innerHTML =

    "Registration Successful for " + name;

    alert(
    "Form Submitted Successfully"
    );
}

/* Double Click Image */

function enlargeImage(){

    document.getElementById("zoomImage")
    .style.width = "600px";
}

/* Character Counter */

function countChars(){

    let text =
    document.getElementById("feedback").value;

    let count = text.length;

    document.getElementById("charCount")
    .innerHTML =

    "Characters: " + count;
}

/* Video Ready */

function videoReady(){

    alert("Video ready to play");
}

/* Geolocation */

function findLocation(){

    navigator.geolocation
    .getCurrentPosition(

        success,
        error
    );
}

function success(position){

    document.getElementById("location")
    .innerHTML =

    "Latitude: " +

    position.coords.latitude +

    "<br><br>Longitude: " +

    position.coords.longitude;
}

function error(){

    alert("Location access denied");
}

/* Console Log */

console.log(
"Portal Loaded Successfully"
);

/* Before Exit Warning */

window.onbeforeunload = function(){

    return
    "Are you sure you want to leave?";
}