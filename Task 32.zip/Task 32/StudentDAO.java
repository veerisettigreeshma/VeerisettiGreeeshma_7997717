import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class StudentDAO {
    private final String url = "jdbc:sqlite:students.db";

    public void insertStudent(int id, String name) {
        String sql = "INSERT INTO students(id, name) VALUES(?, ?)";
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.setString(2, name);
            pstmt.executeUpdate();
            System.out.println("Inserted student successfully!");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void updateStudent(int id, String newName) {
        String sql = "UPDATE students SET name = ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newName);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
            System.out.println("Updated student ID " + id + " successfully!");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        StudentDAO dao = new StudentDAO();
        
        // Setup initial table structure
        try (Connection conn = DriverManager.getConnection(dao.url); Statement stmt = conn.createStatement()) {
            stmt.execute("CREATE TABLE IF NOT EXISTS students (id INTEGER PRIMARY KEY, name TEXT);");
        } catch (Exception ignored) {}

        dao.insertStudent(101, "Charlie");
        dao.updateStudent(101, "Charles");
    }
}