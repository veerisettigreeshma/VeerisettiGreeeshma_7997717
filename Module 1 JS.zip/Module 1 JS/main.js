/* ==========================================================================
   1. JAVASCRIPT BASICS & SETUP
   ========================================================================== */
console.log("Welcome to the Community Portal"); // [cite: 8]

window.addEventListener("load", () => {
    alert("The Community Portal is fully loaded and ready!"); // [cite: 9]
});


/* ==========================================================================
   5. OBJECTS AND PROTOTYPES (Defined early to construct instances)
   ========================================================================== */
// Task: Define Event constructor or class [cite: 28]
class CommunityEvent {
    constructor(id, name, date, category, seats) {
        this.id = id;
        this.name = name;
        this.date = date; // "Upcoming" or "Past"
        this.category = category;
        this.seats = seats;
    }
}

// Task: Add checkAvailability() to prototype [cite: 29]
CommunityEvent.prototype.checkAvailability = function() {
    return this.date === "Upcoming" && this.seats > 0; // [cite: 17, 18]
};


/* ==========================================================================
   6. ARRAYS AND METHODS & 10. MODERN JAVASCRIPT FEATURES
   ========================================================================== */
// Setup seed data
let masterEventsList = [
    new CommunityEvent(1, "Community Food Truck Festival", "Upcoming", "Food", 12),
    new CommunityEvent(2, "Local Charity Run", "Past", "Sports", 50),
    new CommunityEvent(3, "Neighborhood Cleanup Drive", "Upcoming", "Community", 0),
    new CommunityEvent(4, "Rocking Evening Concert", "Upcoming", "Music", 8)
];

// Task 6: Add new events using .push() [cite: 35]
masterEventsList.push(new CommunityEvent(5, "Outdoor Pottery Workshop", "Upcoming", "Art", 5));
masterEventsList.push(new CommunityEvent(6, "Jazz Night Under The Stars", "Upcoming", "Music", 15));

// Task 5: List object keys and values using Object.entries() [cite: 30]
console.log("--- Inspection of First Event Object Entries ---");
Object.entries(masterEventsList[0]).forEach(([key, value]) => {
    console.log(`${key}: ${value}`);
});


/* ==========================================================================
   4. FUNCTIONS, SCOPE, CLOSURES, HIGHER-ORDER FUNCTIONS
   ========================================================================== */
// Task: Create addEvent() [cite: 23]
function addEvent(name, date, category, seats) {
    // 10. Default parameters usage [cite: 59]
    const id = masterEventsList.length + 1;
    const newEvt = new CommunityEvent(id, name, date, category, seats);
    masterEventsList.push(newEvt); // [cite: 35]
    renderPortal();
}

// Task: Use closure to track total registrations for a category [cite: 24]
function makeRegistrationTracker(categoryName) {
    let totalCounter = 0; // Trapped lexical scope variable
    return function(eventName) {
        totalCounter++;
        console.log(`[Closure Tracker] New registration for "${eventName}". Total for ${categoryName}: ${totalCounter}`);
    };
}
const musicTracker = makeRegistrationTracker("Music");

// Task: Pass callbacks to filter functions for dynamic search [cite: 24]
function filterEventsEngine(criterion, matchCallback) {
    // 10. Spread operator to clone list before filtering [cite: 60]
    const clonedList = [...masterEventsList]; 
    return clonedList.filter(evt => matchCallback(evt, criterion));
}

// Callback definition variants
const categoryMatchCallback = (event, cat) => event.category.toLowerCase() === cat.toLowerCase();
const nameSearchCallback = (event, query) => event.name.toLowerCase().includes(query.toLowerCase());


/* ==========================================================================
   7. DOM MANIPULATION & 3. CONDITIONALS / LOOPS
   ========================================================================== */
function renderPortal(eventsToDisplay = masterEventsList) {
    // Task: Access DOM elements using querySelector() [cite: 41]
    const container = document.querySelector("#eventContainer");
    const selectDropdown = document.querySelector("#eventSelect");
    
    container.innerHTML = "";
    selectDropdown.innerHTML = "";

    // Task 3: Loop through using forEach() [cite: 19]
    eventsToDisplay.forEach(event => {
        
        /* Task 3: Use if-else to hide past or full events from client main grid view */
        // Uses the prototype framework method built in Section 5 [cite: 18, 29]
        if (event.checkAvailability()) {
            
            // Task 7: Create and append event cards using createElement() [cite: 42]
            const card = document.createElement("div");
            card.className = "event-card";
            
            // Task 6: Use .map() structural concept equivalent / targeting item variations
            if(event.category === "Music") {
                card.classList.add("music-theme");
            }

            // Task 10: Use destructuring to extract event details [cite: 59]
            const { id, name, date, category, seats } = event;

            // Task 2: Concatenate event info using template literals [cite: 13]
            card.innerHTML = `
                <h3>${name}</h3>
                <p><strong>Category:</strong> ${category}</p>
                <p><strong>Status:</strong> ${date}</p>
                <p><strong>Seats Left:</strong> <span id="seat-count-${id}">${seats}</span></p>
                <button class="reg-btn" data-id="${id}">Register</button>
            `;
            
            container.appendChild(card);

            // Populating registration form dropdown dynamically
            const option = document.createElement("option");
            option.value = id;
            option.textContent = name;
            selectDropdown.appendChild(option);
        }
    });

    // Setup inline click binding for dynamic register buttons
    setupRegisterButtons();
}


/* ==========================================================================
   8. EVENT HANDLING & 3. TRY-CATCH REGISTRATION
   ========================================================================== */
function setupRegisterButtons() {
    // Task 8: Use onclick for "Register" buttons [cite: 47]
    const buttons = document.querySelectorAll(".reg-btn");
    buttons.forEach(btn => {
        btn.onclick = function(e) {
            const eventId = parseInt(e.target.getAttribute("data-id"));
            executeRegistrationWorkflow(eventId);
        };
    });
}

// Task 8: Use onchange to filter events by category [cite: 48]
document.querySelector("#categoryFilter").onchange = function(e) {
    const selectedCategory = e.target.value;
    if (selectedCategory === "all") {
        renderPortal(masterEventsList);
    } else {
        // Section 6: Use .filter() to isolate music/targeted arrays [cite: 36]
        const filtered = filterEventsEngine(selectedCategory, categoryMatchCallback);
        renderPortal(filtered);
    }
};

// Task 8: Use keydown to allow quick search by name [cite: 49]
document.querySelector("#searchBar").onkeydown = function(e) {
    // Captures input tracking value downstream safely
    setTimeout(() => {
        const query = e.target.value;
        const filtered = filterEventsEngine(query, nameSearchCallback);
        renderPortal(filtered);
    }, 10);
};

// Core Action Logic using Error Tracking Structure
function executeRegistrationWorkflow(eventId) {
    // Task 3: Wrap registration logic in try-catch to handle errors [cite: 20]
    try {
        const targetEvent = masterEventsList.find(evt => evt.id === eventId);
        
        console.log(`[Log Action] Registration processing request for Item ID: ${eventId}`); // [cite: 73]

        if (!targetEvent || targetEvent.seats <= 0) {
            // Explicit error instantiation
            throw new Error("Registration Failed: No seats available on this selection."); // [cite: 20]
        }

        // Task 2: Use -- to manage seat count on registration [cite: 13]
        targetEvent.seats--;

        // Fire closure tracking if matching specific category types
        if(targetEvent.category === "Music") {
            musicTracker(targetEvent.name);
        }

        alert(`Successfully registered for "${targetEvent.name}"!`);
        
        // Task 7: Update UI when user registers or cancels [cite: 42]
        renderPortal();

    } catch (error) {
        // Handle gracefully without context crashing [cite: 20]
        alert(`Notice: ${error.message}`);
        console.error(`Error context captured: ${error.message}`); // [cite: 20]
    }
}


/* ==========================================================================
   9. ASYNC JS, PROMISES, ASYNC/AWAIT
   ========================================================================== */
// Mocking an async remote fetch routine
function fetchMockRemoteEndpoint() {
    return new Promise((resolve, reject) => {
        // Section 12: Use setTimeout() to simulate a delayed response [cite: 68]
        setTimeout(() => {
            const remoteData = [
                new CommunityEvent(7, "Symphony Orchestral Concert", "Upcoming", "Music", 20),
                new CommunityEvent(8, "Barbecue Cookoff Competition", "Upcoming", "Food", 15)
            ];
            resolve(remoteData);
        }, 1500);
    });
}

// Task 9: Rewrite using async/await and show loading spinner [cite: 55]
async function loadExternalEventsAsync() {
    const spinner = document.querySelector("#loadingSpinner");
    spinner.style.display = "block"; // Show loading spinner [cite: 55]

    try {
        // Wait on mock response API securely
        const incomingEvents = await fetchMockRemoteEndpoint(); // [cite: 55]
        
        incomingEvents.forEach(evt => masterEventsList.push(evt)); // [cite: 35]
        console.log("Async fetching complete. Master list hydrated via Async/Await.");
        
    } catch (err) {
        console.error("Async payload compilation failure handling logic root context.", err);
    } finally {
        spinner.style.display = "none"; // Hide spinner [cite: 55]
        renderPortal();
    }
}


/* ==========================================================================
   11. WORKING WITH FORMS & 12. AJAX & FETCH API
   ========================================================================== */
const formElement = document.querySelector("#registrationForm");

formElement.onsubmit = function(event) {
    // Task 11: Prevent default form behavior [cite: 64]
    event.preventDefault();

    // Clear inline warnings
    document.querySelectorAll(".error-msg").forEach(el => el.textContent = "");
    const statusMessage = document.querySelector("#formStatusMessage");
    statusMessage.textContent = "";

    // Task 11: Capture name, email, and selected event using form.elements [cite: 64]
    const fullName = formElement.elements["userName"].value.trim();
    const email = formElement.elements["userEmail"].value.trim();
    const selectedEventId = parseInt(formElement.elements["eventSelect"].value);

    let formIsValid = true;

    // Task 11: Validate inputs and show errors inline [cite: 65]
    if (!fullName) {
        document.querySelector("#nameError").textContent = "Name field is required.";
        formIsValid = false;
    }
    if (!email || !email.includes("@")) {
        document.querySelector("#emailError").textContent = "Please verify email format structure.";
        formIsValid = false;
    }
    if (isNaN(selectedEventId)) {
        document.querySelector("#eventError").textContent = "Please pick a valid event schedule target.";
        formIsValid = false;
    }

    if (!formIsValid) return;

    // Package dataset context payload
    const payload = { user: fullName, email: email, eventId: selectedEventId };
    console.log("[Log Submission] Payload generation string format details:", JSON.stringify(payload)); // [cite: 73]

    // Task 12: Use fetch() to POST user data to a mock API [cite: 68]
    // Sending to a safe mock location placeholder endpoint online
    fetch("https://jsonplaceholder.typicode.com/posts", {
        method: "POST",
        body: JSON.stringify(payload),
        headers: { 'Content-type': 'application/json; charset=UTF-8' }
    })
    // Task 9: Use .then() and .catch() to handle results [cite: 54]
    .then(response => {
        if (!response.ok) throw new Error("Server transmission communication drop exception.");
        return response.json();
    })
    .then(data => {
        // Task 12: Show success message after submission [cite: 68]
        statusMessage.style.color = "#2cc185";
        statusMessage.textContent = "Registration submitted successfully! (API Status Valid)";
        
        // Execute operational modifications inside internal engine tracking scope
        executeRegistrationWorkflow(selectedEventId);
    })
    .catch(error => {
        // Task 12: Show failure message after submission [cite: 68]
        statusMessage.style.color = "#e74c3c";
        statusMessage.textContent = `Server Connection Drop: ${error.message}`;
    });
};


/* ==========================================================================
   14. JQUERY & FRAMEWORK TRANSITIONS
   ========================================================================== */
// Task 14: Use $('#submitBtn').click(...) structure equivalent option pattern context
// Emulating standard structural targeting logic natively or through standard binding:
$(document).ready(function() {
    console.log("jQuery initialized and hooked cleanly into application root layout structure.");
    
    // Quick demonstration feature showing dynamic card fading properties using jQuery transitions
    $("#categoryFilter").on("change", function() {
        $(".event-card").hide().fadeIn(400); // Task 14: Use .fadeIn() and .fadeOut() for event cards [cite: 78]
    });
});

/* Benefit of moving to frameworks like React or Vue: [cite: 79]
   Moving to a reactive framework manages UI syncing transparently through state models. 
   Instead of manually finding DOM element handles, creating templates via strings, and rebuilding 
   dropdown matrices inside structural sequences like `renderPortal()`, declarative rendering tracks data 
   mutations and safely pushes exact localized modifications instantly.
*/


/* ==========================================================================
   INITIALIZATION BOOTSTRAPPING RUNDOWN
   ========================================================================== */
// Trigger initial client render layout paint step routine run
renderPortal();

// Fire our simulated remote background async extraction operation processing run 
loadExternalEventsAsync();