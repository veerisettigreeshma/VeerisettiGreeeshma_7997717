USE event_portal;
SELECT u.user_id, u.full_name,
       (SELECT COUNT(*) FROM Registrations r WHERE r.user_id = u.user_id) AS events_registered,
       (SELECT COUNT(*) FROM Feedback f WHERE f.user_id = u.user_id) AS feedback_submitted
FROM Users u;