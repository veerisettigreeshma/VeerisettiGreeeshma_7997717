package com.utils; public class Helper { public static String getGreetingMessage() { return "Hello from the encapsulated com.utils module!"; } }
