package com.greetings; import com.utils.Helper; public class Main { public static void main(String[] args) { System.out.println(Helper.getGreetingMessage()); } }
