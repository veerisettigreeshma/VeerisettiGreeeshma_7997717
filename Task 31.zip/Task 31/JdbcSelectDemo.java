import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class JdbcSelectDemo {
    public static void main(String[] args) {
        String sqliteJarName = "sqlite-jdbc-3.45.1.0.jar"; 
        String slf4jJarName = "slf4j-api-2.0.9.jar";
        String url = "jdbc:sqlite:students.db";
        
        try {
            File sqliteFile = new File(sqliteJarName);
            File slf4jFile = new File(slf4jJarName);
            
            if (!sqliteFile.exists() || !slf4jFile.exists()) {
                System.out.println("ERROR: Make sure both JAR files are in this folder!");
                return;
            }

            // Load both JARs into the ClassLoader so they can see each other
            URL[] urls = new URL[]{ sqliteFile.toURI().toURL(), slf4jFile.toURI().toURL() };
            URLClassLoader loader = new URLClassLoader(urls);
            
            // Explicitly load the SQLite JDBC driver class
            Class<?> driverClass = Class.forName("org.sqlite.JDBC", true, loader);
            Driver driver = (Driver) driverClass.getDeclaredConstructor().newInstance();
            
            System.out.println("All drivers and dependencies loaded successfully!");
            
            Properties props = new Properties();
            try (Connection conn = driver.connect(url, props);
                 Statement stmt = conn.createStatement()) {
                
                stmt.execute("CREATE TABLE IF NOT EXISTS students (id INTEGER PRIMARY KEY, name TEXT);");
                stmt.execute("INSERT OR IGNORE INTO students (id, name) VALUES (1, 'Alice'), (2, 'Bob');");
                
                String sql = "SELECT id, name FROM students [cite: 234]";
                try (ResultSet rs = stmt.executeQuery(sql)) {
                    System.out.println("\nID\tName");
                    System.out.println("------------------");
                    while (rs.next()) {
                        System.out.println(rs.getInt("id") + "\t" + rs.getString("name"));
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("\nDatabase error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}