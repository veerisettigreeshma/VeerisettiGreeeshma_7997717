import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

// A sample class containing a private field and private method
class MysteryBox {
    private String secretKey = "SUPER_SECRET_VALUE";

    private void revealSecret(String user) {
        System.out.println("Access Granted to: " + user);
        System.out.println("The secret key inside the box is: " + secretKey);
    }
}

public class ReflectionDemo {
    public static void main(String[] args) {
        System.out.println("=== JAVA REFLECTION DEMO ===");
        System.out.println("------------------------------------");

        try {
            // 1. Get the Class object associated with MysteryBox
            Class<?> clazz = MysteryBox.class;
            System.out.println("Inspecting class: " + clazz.getName());

            // 2. Instantiate the class dynamically using reflection
            Constructor<?> constructor = clazz.getDeclaredConstructor();
            Object boxInstance = constructor.newInstance();

            // 3. Access and modify the PRIVATE field 'secretKey'
            Field privateField = clazz.getDeclaredField("secretKey");
            // CRITICAL STEP: Tells Java to ignore the 'private' keyword restriction
            privateField.setAccessible(true); 
            
            System.out.println("Original Private Field Value: " + privateField.get(boxInstance));
            
            // We can even change its value dynamically!
            privateField.set(boxInstance, "MUTATED_BY_REFLECTION_2026");
            System.out.println("Modified Private Field Value: " + privateField.get(boxInstance));

            System.out.println("\nInvoking Private Method...");
            // 4. Access and invoke the PRIVATE method 'revealSecret'
            // We pass the method name and its expected parameter types (String.class)
            Method privateMethod = clazz.getDeclaredMethod("revealSecret", String.class);
            privateMethod.setAccessible(true); // Bypass private security restriction again

            // Invoke the method on our boxInstance, passing "AdminUser" as the argument
            privateMethod.invoke(boxInstance, "AdminUser");

        } catch (Exception e) {
            System.err.println("Reflection failed!");
            e.printStackTrace();
        }
    }
}