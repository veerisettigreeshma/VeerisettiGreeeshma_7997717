public class TypeCastingDemo {
    public static void main(String[] args) {

        double d = 45.89;
        int a = (int)d;

        int x = 50;
        double y = x;

        System.out.println("Double = " + d);
        System.out.println("Int = " + a);

        System.out.println("Original Int = " + x);
        System.out.println("Converted Double = " + y);
    }
}