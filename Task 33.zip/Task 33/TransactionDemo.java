import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Properties;

public class TransactionDemo {
    public static void main(String[] args) {
        // Pointing back to Task 31 where the downloaded JAR files live
        String sqliteJarPath = "../Task 31/sqlite-jdbc-3.45.1.0.jar"; 
        String slf4jJarPath = "../Task 31/slf4j-api-2.0.9.jar";
        String url = "jdbc:sqlite:bank.db";
        
        try {
            File sqliteFile = new File(sqliteJarPath);
            File slf4jFile = new File(slf4jJarPath);
            
            if (!sqliteFile.exists() || !slf4jFile.exists()) {
                System.out.println("ERROR: Dependencies not found! Make sure you are running from inside 'Task 33' and the JAR files exist inside 'Task 31'.");
                return;
            }

            // Load the drivers dynamically from the Task 31 folder
            URL[] urls = new URL[]{ sqliteFile.toURI().toURL(), slf4jFile.toURI().toURL() };
            URLClassLoader loader = new URLClassLoader(urls);
            Class<?> driverClass = Class.forName("org.sqlite.JDBC", true, loader);
            Driver driver = (Driver) driverClass.getDeclaredConstructor().newInstance();
            
            Properties props = new Properties();
            try (Connection conn = driver.connect(url, props);
                 Statement stmt = conn.createStatement()) {
                
                // 1. Setup sample bank accounts
                stmt.execute("CREATE TABLE IF NOT EXISTS accounts (id TEXT PRIMARY KEY, balance REAL);");
                stmt.execute("INSERT OR IGNORE INTO accounts VALUES ('ACC1', 1000.0), ('ACC2', 500.0);");

                System.out.println("Starting money transfer transaction...");

                // 2. DISABLE Auto-Commit to handle transaction block manually
                conn.setAutoCommit(false);

                try (PreparedStatement debit = conn.prepareStatement("UPDATE accounts SET balance = balance - ? WHERE id = ?");
                     PreparedStatement credit = conn.prepareStatement("UPDATE accounts SET balance = balance + ? WHERE id = ?")) {
                    
                    double transferAmount = 200.0;

                    // Step A: Debit $200 from ACC1
                    debit.setDouble(1, transferAmount);
                    debit.setString(2, "ACC1");
                    debit.executeUpdate();
                    System.out.println("Step A: Successfully debited ACC1.");

                    // Step B: Credit $200 to ACC2
                    credit.setDouble(1, transferAmount);
                    credit.setString(2, "ACC2");
                    credit.executeUpdate();
                    System.out.println("Step B: Successfully credited ACC2.");

                    // If both steps succeed without an error, permanently commit changes
                    conn.commit();
                    System.out.println("Transaction Committed Successfully! Balances updated permanently.");

                } catch (Exception ex) {
                    // If an unexpected error happens mid-way, cancel everything
                    conn.rollback();
                    System.err.println("Transaction Failed! Rolling back all partial mutations to protect account balances.");
                    System.err.println("Reason: " + ex.getMessage());
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}