USE event_portal;
SELECT event_id, title 
FROM Events
WHERE event_id NOT IN (SELECT event_id FROM Sessions);