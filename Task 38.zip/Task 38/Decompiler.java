import java.util.spi.ToolProvider;

public class Decompiler {
    public static void main(String[] args) {
        // Locate Java's internal bytecode viewer engine
        ToolProvider javap = ToolProvider.findFirst("javap")
            .orElseThrow(() -> new RuntimeException("Internal disassembler engine could not be loaded."));
        
        System.out.println("=== DECOMPILING PRIVATE MEMBERS OF SECRETAPP.CLASS ===");
        System.out.println("-------------------------------------------------------");
        
        // Pass the "-p" flag to expose private elements, and "-c" to see their assembly
        javap.run(System.out, System.err, "-p", "-c", "SecretApp");
    }
}