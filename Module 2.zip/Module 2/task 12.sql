USE event_portal;
SELECT event_id, COUNT(*) AS session_count
FROM Sessions
GROUP BY event_id
HAVING COUNT(*) = (
    SELECT COUNT(*) 
    FROM Sessions 
    GROUP BY event_id 
    ORDER BY COUNT(*) DESC 
    LIMIT 1
);