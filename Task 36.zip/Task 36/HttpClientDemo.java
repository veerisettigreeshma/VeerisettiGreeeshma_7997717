import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;

public class HttpClientDemo {
    public static void main(String[] args) {
        System.out.println("=== HTTP CLIENT DEMO ===");
        System.out.println("Sending GET request to mock API...");
        System.out.println("----------------------------------------");

        // 1. Create a modern HttpClient instance
        HttpClient client = HttpClient.newHttpClient();

        // 2. Build an HTTP GET Request pointing to the target URL
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://jsonplaceholder.typicode.com/todos/1"))
                .GET() // Defines the HTTP method
                .build();

        // 3. Send the request synchronously and handle the response
        try {
            // BodyHandlers.ofString() ensures the web server's response binary payload is read as text
            HttpResponse<String> response = client.send(request, BodyHandlers.ofString());

            // 4. Print the HTTP Status Code (200 means Success!)
            System.out.println("HTTP Status Code: " + response.statusCode());
            System.out.println("Response Headers: " + response.headers().map().get("content-type"));
            System.out.println("----------------------------------------");
            
            // 5. Print the actual raw JSON response body
            System.out.println("Response Body (JSON):");
            System.out.println(response.body());

        } catch (Exception e) {
            System.err.println("An error occurred while making the HTTP call:");
            e.printStackTrace();
        }
    }
}